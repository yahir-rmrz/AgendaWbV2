DOKUWIKI PARA AGENDAWEB

Este paquete incluye el codigo base de DokuWiki 2026-07-14c (Mort), sin datos, usuarios ni configuracion privada del equipo local.

ANTES DE PUBLICAR:
1. En el servidor, mueve conf/ y data/ fuera del directorio publico (por ejemplo, a ~/agendaweb_wiki_private/).
2. Configura DokuWiki para usar esas rutas privadas mediante la configuracion de directorios de DokuWiki y las reglas del servidor web.
3. Configura HTTPS y bloquea el acceso web a conf/, data/, bin/ y vendor/ segun la guia oficial y el servidor usado.
4. No copies users.auth.php ni acl.auth.php del ZIP local: contenian una cuenta local y permisos de escritura anonima.
5. Configura ACL cerrada: sin acceso para @ALL; lectura para usuarios autenticados; edicion solo para el grupo autorizado.
6. La autenticacion compartida con AgendaWeb aun debe integrarse y probarse en el hosting. No habilites la Wiki publica hasta verificar que un visitante sin sesion no puede leer ni modificar paginas.

IMPORTANTE: el proyecto AgendaWeb original se conserva; esta carpeta wiki es una base limpia de DokuWiki.
