# ACL AgendaWeb: anónimos sin acceso; usuarios registrados solo lectura; admin edición total
*	@admin	16
*	@ALL	1
*	@user	1
