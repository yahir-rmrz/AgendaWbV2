<?php

$conf['authtype'] = 'authplain';
$conf['useacl'] = 1;
$conf['superuser'] = '@admin';
$conf['disableactions'] = 'register';
$conf['title'] = 'AgendaWeb - Documentación';
$conf['lang'] = 'es';
